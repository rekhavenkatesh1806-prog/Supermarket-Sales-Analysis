"""
analysis.py
-----------
Reads data/supermarket_sales.csv and produces:
  1. Branch-wise sales analysis
  2. Product line performance
  3. Revenue trends over time
  4. Payment method analysis
  5. Customer rating analysis
  6. A text summary report of key business insights

Outputs:
  - PNG charts inside output/
  - output/insights_report.txt  (plain-text business insights)

Run this AFTER generate_data.py (or after placing your own
supermarket_sales.csv with the same column names in data/).
"""

import pandas as pd
import matplotlib
matplotlib.use("Agg")  # no display needed, just save files
import matplotlib.pyplot as plt

pd.set_option("display.width", 120)

# ---------------------------------------------------------------
# 1. LOAD DATA
# ---------------------------------------------------------------
df = pd.read_csv("data/supermarket_sales.csv")
df["Date"] = pd.to_datetime(df["Date"])
df["Month"] = df["Date"].dt.to_period("M").astype(str)
df["Weekday"] = df["Date"].dt.day_name()

report_lines = []


def log(line=""):
    """Print to console AND collect for the report file."""
    print(line)
    report_lines.append(line)


log("=" * 70)
log("SUPERMARKET SALES ANALYSIS — BUSINESS INSIGHTS REPORT")
log("=" * 70)
log(f"Rows analyzed: {len(df)}   |   Date range: {df['Date'].min().date()} to {df['Date'].max().date()}")
log("")

# ---------------------------------------------------------------
# 2. BRANCH-WISE SALES
# ---------------------------------------------------------------
log("-" * 70)
log("1. BRANCH-WISE PERFORMANCE")
log("-" * 70)

branch_summary = df.groupby("Branch").agg(
    Total_Revenue=("Total", "sum"),
    Avg_Sale=("Total", "mean"),
    Transactions=("Invoice ID", "count"),
    Avg_Rating=("Rating", "mean"),
).round(2).sort_values("Total_Revenue", ascending=False)
log(branch_summary.to_string())

top_branch = branch_summary["Total_Revenue"].idxmax()
low_branch = branch_summary["Total_Revenue"].idxmin()
log(f"\n-> Best performing branch: {top_branch} "
    f"(Revenue: {branch_summary.loc[top_branch,'Total_Revenue']:.2f})")
log(f"-> Weakest branch: {low_branch} "
    f"(Revenue: {branch_summary.loc[low_branch,'Total_Revenue']:.2f})")
log("")

fig, ax = plt.subplots(figsize=(7, 5))
branch_summary["Total_Revenue"].plot(kind="bar", ax=ax, color=["#2E86AB", "#A23B72", "#F18F01"])
ax.set_title("Total Revenue by Branch")
ax.set_ylabel("Revenue")
ax.set_xlabel("Branch")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("output/01_branch_revenue.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 3. PRODUCT LINE PERFORMANCE
# ---------------------------------------------------------------
log("-" * 70)
log("2. PRODUCT LINE PERFORMANCE")
log("-" * 70)

product_summary = df.groupby("Product line").agg(
    Total_Revenue=("Total", "sum"),
    Units_Sold=("Quantity", "sum"),
    Avg_Rating=("Rating", "mean"),
).round(2).sort_values("Total_Revenue", ascending=False)
log(product_summary.to_string())

top_product = product_summary["Total_Revenue"].idxmax()
low_product = product_summary["Total_Revenue"].idxmin()
log(f"\n-> Top revenue-generating product line: {top_product}")
log(f"-> Lowest revenue-generating product line: {low_product}")
log("")

fig, ax = plt.subplots(figsize=(9, 5))
product_summary["Total_Revenue"].plot(kind="barh", ax=ax, color="#2E86AB")
ax.set_title("Total Revenue by Product Line")
ax.set_xlabel("Revenue")
plt.tight_layout()
plt.savefig("output/02_product_line_revenue.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 4. REVENUE TRENDS OVER TIME
# ---------------------------------------------------------------
log("-" * 70)
log("3. REVENUE TRENDS")
log("-" * 70)

daily_revenue = df.groupby("Date")["Total"].sum()
monthly_revenue = df.groupby("Month")["Total"].sum()
log("Monthly revenue:")
log(monthly_revenue.round(2).to_string())

weekday_revenue = df.groupby("Weekday")["Total"].sum().reindex(
    ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
)
best_day = weekday_revenue.idxmax()
log(f"\n-> Best day of the week for sales: {best_day} "
    f"(Revenue: {weekday_revenue.max():.2f})")
log("")

fig, axes = plt.subplots(1, 2, figsize=(13, 5))
daily_revenue.plot(ax=axes[0], color="#2E86AB")
axes[0].set_title("Daily Revenue Trend")
axes[0].set_ylabel("Revenue")
axes[0].set_xlabel("Date")

weekday_revenue.plot(kind="bar", ax=axes[1], color="#A23B72")
axes[1].set_title("Revenue by Day of Week")
axes[1].set_ylabel("Revenue")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("output/03_revenue_trends.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 5. PAYMENT METHOD ANALYSIS
# ---------------------------------------------------------------
log("-" * 70)
log("4. PAYMENT METHOD ANALYSIS")
log("-" * 70)

payment_summary = df.groupby("Payment").agg(
    Total_Revenue=("Total", "sum"),
    Transactions=("Invoice ID", "count"),
).round(2).sort_values("Total_Revenue", ascending=False)
payment_summary["Share_%"] = (payment_summary["Total_Revenue"] /
                               payment_summary["Total_Revenue"].sum() * 100).round(1)
log(payment_summary.to_string())

top_payment = payment_summary["Total_Revenue"].idxmax()
log(f"\n-> Most used payment method (by revenue): {top_payment}")
log("")

fig, ax = plt.subplots(figsize=(6, 6))
ax.pie(payment_summary["Total_Revenue"], labels=payment_summary.index,
       autopct="%1.1f%%", colors=["#2E86AB", "#A23B72", "#F18F01"], startangle=90)
ax.set_title("Revenue Share by Payment Method")
plt.tight_layout()
plt.savefig("output/04_payment_methods.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 6. CUSTOMER RATINGS
# ---------------------------------------------------------------
log("-" * 70)
log("5. CUSTOMER RATING ANALYSIS")
log("-" * 70)

rating_by_branch = df.groupby("Branch")["Rating"].mean().round(2)
rating_by_product = df.groupby("Product line")["Rating"].mean().round(2).sort_values(ascending=False)
log("Average rating by branch:")
log(rating_by_branch.to_string())
log("\nAverage rating by product line:")
log(rating_by_product.to_string())

best_rated = rating_by_product.idxmax()
worst_rated = rating_by_product.idxmin()
log(f"\n-> Highest rated product line: {best_rated} ({rating_by_product.max()})")
log(f"-> Lowest rated product line: {worst_rated} ({rating_by_product.min()}) — investigate quality/service")
log("")

fig, ax = plt.subplots(figsize=(9, 5))
rating_by_product.plot(kind="bar", ax=ax, color="#F18F01")
ax.set_title("Average Customer Rating by Product Line")
ax.set_ylabel("Avg Rating (out of 10)")
ax.set_ylim(0, 10)
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig("output/05_ratings_by_product.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 7. CUSTOMER TYPE & GENDER
# ---------------------------------------------------------------
log("-" * 70)
log("6. CUSTOMER SEGMENT ANALYSIS")
log("-" * 70)

customer_summary = df.groupby("Customer type").agg(
    Total_Revenue=("Total", "sum"),
    Avg_Spend=("Total", "mean"),
    Avg_Rating=("Rating", "mean"),
).round(2)
log(customer_summary.to_string())

gender_summary = df.groupby("Gender")["Total"].sum().round(2)
log("\nRevenue by gender:")
log(gender_summary.to_string())
log("")

# ---------------------------------------------------------------
# 8. KEY TAKEAWAYS
# ---------------------------------------------------------------
log("=" * 70)
log("KEY BUSINESS TAKEAWAYS")
log("=" * 70)
log(f"1. Branch '{top_branch}' leads in revenue; branch '{low_branch}' lags behind "
    "and may need marketing or staffing attention.")
log(f"2. '{top_product}' is the strongest product line — consider promoting it further "
    f"or ensuring strong stock levels. '{low_product}' underperforms and may need bundling/discounts.")
log(f"3. Sales peak on {best_day}s — staffing and inventory should be optimized around this.")
log(f"4. '{top_payment}' is the leading payment method ({payment_summary.loc[top_payment,'Share_%']}% "
    "of revenue) — ensure this channel is always frictionless.")
log(f"5. '{worst_rated}' has the lowest customer satisfaction — worth a service/quality review.")
log("=" * 70)

# Save report to file
with open("output/insights_report.txt", "w") as f:
    f.write("\n".join(report_lines))

print("\nAll charts and the insights report have been saved in the 'output/' folder.")
