"""
generate_data.py
-----------------
Creates a synthetic "supermarket_sales.csv" dataset that mirrors the
structure of the well-known Kaggle "Supermarket Sales" dataset:

Invoice ID, Branch, City, Customer type, Gender, Product line,
Unit price, Quantity, Tax 5%, Total, Date, Time, Payment,
cogs, gross margin percentage, gross income, Rating

Run this first. It writes data/supermarket_sales.csv
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(42)

N_ROWS = 1000

branches = {
    "A": "Yangon",
    "B": "Mandalay",
    "C": "Naypyitaw",
}

product_lines = [
    "Health and beauty",
    "Electronic accessories",
    "Home and lifestyle",
    "Sports and travel",
    "Food and beverages",
    "Fashion accessories",
]

payments = ["Cash", "Credit card", "Ewallet"]
customer_types = ["Member", "Normal"]
genders = ["Male", "Female"]

start_date = datetime(2024, 1, 1)
end_date = datetime(2024, 3, 31)
date_range_days = (end_date - start_date).days

rows = []
for i in range(1, N_ROWS + 1):
    branch = np.random.choice(list(branches.keys()), p=[0.36, 0.33, 0.31])
    city = branches[branch]
    customer_type = np.random.choice(customer_types, p=[0.49, 0.51])
    gender = np.random.choice(genders, p=[0.49, 0.51])

    # Give product lines slightly different popularity / price ranges
    product_line = np.random.choice(
        product_lines, p=[0.18, 0.17, 0.16, 0.16, 0.18, 0.15]
    )
    price_ranges = {
        "Health and beauty": (10, 100),
        "Electronic accessories": (10, 100),
        "Home and lifestyle": (10, 100),
        "Sports and travel": (10, 100),
        "Food and beverages": (10, 100),
        "Fashion accessories": (10, 100),
    }
    low, high = price_ranges[product_line]
    unit_price = round(np.random.uniform(low, high), 2)
    quantity = int(np.random.randint(1, 11))

    tax = round(unit_price * quantity * 0.05, 4)
    total = round(unit_price * quantity + tax, 4)
    cogs = round(unit_price * quantity, 2)
    gross_margin_pct = 4.761904762
    gross_income = round(tax, 4)

    # Random date/time, with a mild weekend & month-end sales bump
    rand_day = np.random.randint(0, date_range_days + 1)
    sale_date = start_date + timedelta(days=rand_day)
    hour = np.random.choice(range(10, 21), p=[0.06,0.07,0.08,0.09,0.10,0.10,0.10,0.10,0.11,0.10,0.09])
    minute = np.random.randint(0, 60)
    sale_time = f"{hour:02d}:{minute:02d}"

    payment = np.random.choice(payments, p=[0.34, 0.31, 0.35])
    rating = round(np.random.uniform(4.0, 10.0), 1)
    rating = min(rating, 10.0)
    # keep ratings in realistic 4-10 band similar to source dataset
    rating = round(np.random.normal(6.97, 1.7), 1)
    rating = min(max(rating, 4.0), 10.0)

    rows.append({
        "Invoice ID": f"{branch}-{100000+i}",
        "Branch": branch,
        "City": city,
        "Customer type": customer_type,
        "Gender": gender,
        "Product line": product_line,
        "Unit price": unit_price,
        "Quantity": quantity,
        "Tax 5%": tax,
        "Total": total,
        "Date": sale_date.strftime("%Y-%m-%d"),
        "Time": sale_time,
        "Payment": payment,
        "cogs": cogs,
        "gross margin percentage": gross_margin_pct,
        "gross income": gross_income,
        "Rating": rating,
    })

df = pd.DataFrame(rows)
df.to_csv("data/supermarket_sales.csv", index=False)
print(f"Created data/supermarket_sales.csv with {len(df)} rows")
print(df.head())
