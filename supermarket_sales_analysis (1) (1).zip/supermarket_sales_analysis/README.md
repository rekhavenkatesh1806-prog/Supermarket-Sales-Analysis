# Supermarket Sales Analysis

A complete mini-project that analyzes supermarket sales data to generate
business insights on branch performance, product performance, revenue
trends, payment methods, and customer ratings.

## Project structure

```
supermarket_sales_analysis/
├── data/
│   └── supermarket_sales.csv   <- dataset (created by generate_data.py)
├── scripts/
│   ├── generate_data.py        <- creates the sample dataset
│   └── analysis.py             <- runs the full analysis
├── output/                     <- charts + report are saved here
└── README.md
```

## What it analyzes
1. **Branch-wise sales** — revenue, average sale, transactions, ratings per branch
2. **Product line performance** — revenue and units sold per category
3. **Revenue trends** — daily trend, monthly totals, best day of the week
4. **Payment methods** — Cash vs Credit Card vs E-wallet, revenue share
5. **Customer ratings** — average rating by branch and by product line
6. **Customer segments** — Member vs Normal, Male vs Female spend

The dataset included here is **synthetic** (1,000 rows, randomly generated
but realistic), built in the same format as the popular Kaggle "Supermarket
Sales" dataset. If you have your own real sales CSV, just replace
`data/supermarket_sales.csv` with it — as long as it has the same column
names (Branch, City, Customer type, Gender, Product line, Unit price,
Quantity, Tax 5%, Total, Date, Time, Payment, cogs, gross margin percentage,
gross income, Rating), `analysis.py` will work on it unchanged.

## Requirements
- Python 3.8+
- pandas
- matplotlib
- numpy

## How to run

### 1. Install Python (if you don't have it)
Download from https://www.python.org/downloads/ (make sure to check
"Add Python to PATH" during install on Windows).

### 2. Open a terminal / command prompt in the project folder
- **Windows**: open the `supermarket_sales_analysis` folder in File
  Explorer, click the address bar, type `cmd`, press Enter.
- **Mac/Linux**: open Terminal, then `cd path/to/supermarket_sales_analysis`

### 3. Install the required libraries
```bash
pip install pandas matplotlib numpy
```

### 4. Generate the dataset
```bash
python scripts/generate_data.py
```
This creates `data/supermarket_sales.csv`.

### 5. Run the analysis
```bash
python scripts/analysis.py
```
This prints the full insights report to your terminal **and** saves
everything to the `output/` folder.

## Where to see the output
Open the `output/` folder after running step 5. You'll find:

| File                              | What it shows                                |
|------------------------------------|-----------------------------------------------|
| `01_branch_revenue.png`            | Bar chart — total revenue per branch          |
| `02_product_line_revenue.png`      | Horizontal bar chart — revenue per product line |
| `03_revenue_trends.png`            | Daily revenue trend + revenue by weekday      |
| `04_payment_methods.png`           | Pie chart — revenue share by payment method   |
| `05_ratings_by_product.png`        | Bar chart — average customer rating per product line |
| `insights_report.txt`              | Full text report with numbers and written business takeaways |

Just double-click the PNG files to view the charts, and open
`insights_report.txt` in any text editor (or Notepad/TextEdit) to read the
full written summary.

## Using this for a college project / submission
- You can screenshot or embed the PNGs from `output/` directly into your
  report or PPT.
- `insights_report.txt` already contains ready-made written insights
  ("Key Business Takeaways" section at the bottom) you can quote or adapt.
- To analyze a *different* time period or add more rows, open
  `scripts/generate_data.py` and change `N_ROWS`, `start_date`, or
  `end_date`, then re-run steps 4 and 5.
